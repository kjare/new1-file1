#include<iostream>
using namespace std;

class Complex
{
	int real,img;
	public: static int cnt;
	public:
		Complex()
		{
			cout<<"default is invoked\n";
			this->real=real;
			this->img=img;
			cnt++;
		}

	static int getcnt()
	{
		return cnt;
	}
	
};
int Complex::cnt=0;
int main()
{
	Complex c1;
	//Complex c2(10,10);
	cout<<"no of obj created"<<Complex::getcnt();
}




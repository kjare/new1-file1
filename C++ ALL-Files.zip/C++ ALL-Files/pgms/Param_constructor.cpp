#include<iostream>
using namespace std;

class Date1
{
	int date,month,year;
	public:
		
		void display()
		{
			cout<<"Congratulations!!!Your Birthday is : "<<date<<"/"<<month<<"/"<<year<<endl;
		}
		
		Date1(int d);
		Date1(int d,int m);
		Date1(int d,int m,int y);
		

};

Date1::Date1(int d)
{
	date=d;
	
}
Date1::Date1(int d,int m)
{
	date=d;
	month=m;
}
Date1::Date1(int d,int m,int y)
{
	date=d;
	month=m;
	year=y;	
}

int main()
{
	Date1 d1(12);
	Date1 d2(16,20);
	Date1 d3(11,14,56);
	d1.display();
	d2.display();
	d3.display();
	return 0;
	
}


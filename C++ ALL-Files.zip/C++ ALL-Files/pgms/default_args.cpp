#include<iostream>
using namespace std;
void display(char='*',int=5);
int main()
{
	cout<<"No Arguments passed:";
	display();
	cout<<"first argument passed";
	display('#');
	cout<<"Both argument passed";
	display('$',10);
}

void display(char c,int count)
{
	for (int i=1;i<=count;++i)
	{
		cout<<c;
	}
}

#include<iostream>
using namespace std;

int main()
{
	
	int n,fact=1,t=1;
	cout<<"Enter the number";
	cin>>n;
	while(t<=n)
	{
		fact=fact*t;
		t++;
	}
	cout<<fact;
	return 0;
}

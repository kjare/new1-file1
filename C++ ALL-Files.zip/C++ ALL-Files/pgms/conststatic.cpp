#include<iostream>
using namespace std;

class Complex
{
	int real,img;
	public:	static const int cnt1;
	private:static const int cnt2;
	public:	
		Complex()
		{
			cout<<"default is invoked\n";
			real=5;
			img=5;
			
		}
	static int getcnt()
	{
		return cnt2;
	}
	
};
const int Complex::cnt1=5;
const int Complex::cnt2=10;
int main()
{
	Complex c1;
	Complex c2;
	cout<<"no of obj created"<<Complex::getcnt()<<endl;
	cout<<"size of obj is : "<<sizeof(c1)<<endl;
	cout<<Complex::getcnt;
}




#include<iostream>
using namespace std;

int main()
{
	int a,b,c,d,e,n=20;
	
	for(int i=1;i<=5;i++)
	{
		cout<<"Enter 5 marks of each student"<<endl;
		cin>>a>>b>>c>>d>>e;
		int sum=a+b+c+d+e;
		float avg=(float)sum/5;
		cout<<"Average marks of student no : "<<i<<" is "<<avg;
		
	}
}

#include<stdio.h>
#include<string.h>
int main()
{
	char str[10];
	int length=0,i;
		printf("Enter the valid string ");

	scanf("%s",&str);
/*		while (str[i]!='\0')
	{
		length++;
		i++;
	}
	*/
	
	for(i=0;str[i]!='\0';i++)
	{
			length++;
	}	
	printf("Length of the string is %d",length);

	return 0;
	
}

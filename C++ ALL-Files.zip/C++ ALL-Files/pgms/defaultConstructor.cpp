#include<iostream>
using namespace std;

class Date1
{
	int date,month,year;
	
	public:
		
		Date1()
		{
			cout<<"Enter the Date : ";
			cin>>date;	
			
			cout<<"Enter the Month : ";
			cin>>month;	
			
			cout<<"Enter the Year : ";
			cin>>year;
		}
		void display()
		{
			cout<<"Congratulations!!!Your Birthday is : "<<date<<"/"<<month<<"/"<<year<<endl;
		}
		
};

int main()
{
	Date1 d1;

	d1.display();
	return 0;
	
}


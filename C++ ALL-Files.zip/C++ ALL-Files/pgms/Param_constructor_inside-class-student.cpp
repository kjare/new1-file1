#include<iostream>
#include<String.h>

using namespace std;

class Student
{
	int id;
	char name[10];
	char gender[10];
	public:
		
		void display()
		{
			cout<<"your info: "<<id<<name<<gender<<endl;
		}
		
		Student(int d,char* n, char* g)
		{
			id=d;
			strcpy(name,n);
			strcpy(gender,g);

		}
		Student()
		{
			id=5;
			name[]="fjf";
			gender[]="thu";
		}
};

int main()
{
	//Student s1(1,"guik","oygg");
	Student s1;
	s1.display();
}

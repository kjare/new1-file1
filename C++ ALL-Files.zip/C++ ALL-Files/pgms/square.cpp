#include<iostream>
using namespace std;

int main()
{
	int a,ans;
	cout<<"enter a no:"<<endl;
	cin>>a;
	ans=a*a;
	cout<<"ans is:"<<ans<<endl;
	return 0;
}

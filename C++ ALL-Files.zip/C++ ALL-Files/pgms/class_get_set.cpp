#include<iostream>
using namespace std;

class Complex
{
	int real,img;
	public:
		void getData()
		{
			cout<<"enter the real and imaginary values";
			cin>>real>>img;
			
		}
		void display()
		{
			cout<<"complex no is :"<<real<<"+"<<img<<"i"<<endl;
		}		
		void acceptParam(int ,int);
		
		void setReal(int r)
		{
			real=r;
		}
		
			void setImg(int i)
		{
			img=i;
		}
		
		int getReal()
		{
			return real;
		}
		int getImg()
		{
			return img;
		}
};
void Complex::acceptParam(int r,int i)
{
	real =r;
	img=i;
	
}


int main()
{
	Complex c1;
	cout<<"size of object C1 : "<<sizeof(c1)<<endl;
//	c1.getData();
//	c1.display();
	Complex c2;
	//c2.acceptParam(2,4);
//	c2.display();
	//c2.setReal(8);
	//c2.display();
	
	c2.setImg(7);
	c2.display();
	cout<<"Modified real part is : "<<c2.getImg()<<endl;

	
}


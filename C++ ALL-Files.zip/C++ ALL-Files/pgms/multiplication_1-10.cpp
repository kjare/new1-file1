#include<iostream>
using namespace std;

int main()
{
	int ans=1,t=1;
	while(t<=10)
	{
		ans=ans*t;
		t++;
	}
	cout<<ans;
	return 0;
}

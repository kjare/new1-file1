#include<iostream>
using namespace std;
#include<string.h>
class Date1
{
	int dd,mm,yy;
	public:
		void getdata()
		{
			cout<<"Enter date : ";
			cin>>dd>>mm>>yy;
		}
		void putdata()
		{
			cout<<"Student's date of birth : ";
			cin>>dd>>mm>>yy;
		}
};
class Student:public Date1
{
 	int rollno;
 	char name[10];
 	int marks[3];
 	int sum=0;
 	float avg=0;
 	Date1 d;
 	
 	
 	public:
 	void getdata()
		{
			cout<<"Enter rollno\n";
			cin>>rollno;
			cout<<"enter student name\n";
			cin>>name;
			
			cout<<"\nEnter 5 subject marks : \n";
            
			 for(int i=1;i<=5;i++)
			 {
			 	cout<<"Subject "<<i<<":";
			 	cin>>marks[i];
			 	cout<<endl;
			 	sum+=marks[i];
			 } 
			 avg=(float)sum/5;		
			 d.getdata();
		}
			void putdata()
		{
			cout<<"\nRoll no. :"<<rollno<<"\nName : "<<name<<"\nAverage : "<<avg<<endl;
			d.putdata();
		}
		int getrollno()
		{
			return rollno;
		}
		char* getname()
		{
			return name;
		}
		void setrollno(int r)
		{
			rollno=r;
		}
		void setname(char* n)
		{
			strcpy(name,n);
		}	
};

int main()
{
	Student s[10],temp;
	int i,n,j;
	cout<<"Enter no. of student : \n";
	cin>>n;
	for(i=0;i<n;i++)
	{
		s[i].getdata();
		
	}
	for(i=0;i<n;i++)
	{
		s[i].putdata();
		
	}
	cout<<"The Sorted data is according to roll no ";
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(s[i].getrollno()>s[j].getrollno())
			{
				temp=s[i];
				s[i]=s[j];
				s[j]=temp;
			}
			
		}
	}
	for(i=0;i<n;i++)
	s[i].putdata();
}

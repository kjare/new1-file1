#include<stdio.h>
#include<string.h>
int main()
{
	char str[];
	int length=0;
	scanf("%s",&str);
	
	return 0;
	
}

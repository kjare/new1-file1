#include<iostream>
using namespace std;

int main()
{
	float r,c;
	const float pi=3.142f;
	cout<<"enter radius";
	cin>>r;
	c=2*pi*r;
	cout<<"circumference is "<<c;
}


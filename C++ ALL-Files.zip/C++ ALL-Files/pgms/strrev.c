#include<stdio.h>
char s1[10],s2[20];
int length=0,s1len=0,i;
void main()
{
	
	printf("enter a string :");
	scanf("%s",&s1);
	
	for(i=0;s1[i]!='\0';i++)
	{
			length++;
	}
	s1len=length-1;
	rev(s1,s2,s1len);
		
}

void rev(char *,char *,int)
{	int i=0;
	while(s1len!=0)
	{
		
		s2[i]=s1[s1len];
		i++;
		s1len--;
	}
	s2[i]='\0';
	printf("Reversed string :%s", s2);		
}



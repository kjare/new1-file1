#include <iostream>
using namespace std;

int main()
{
	int a, b;
	cout<<"Enter values of a and b";
	cin>>a>>b;
	int c=a+b;
	cout<<"addition "<<c;
	
}

#include<iostream>
using namespace std;
//calculate area of rectangle
int main()
{
	int len, breath;
	cout<<"Enter length and breath of rectangle is:"<<endl;
	cin>>len>>breath;
 	cout<<"area of reactanle is ="<<len*breath<<endl;
	
}

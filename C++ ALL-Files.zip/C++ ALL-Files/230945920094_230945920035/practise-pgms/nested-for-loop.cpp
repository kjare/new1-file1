#include<iostream>
#include<Math.h>
using namespace std;

int main()
{
	
	int a,b,ans=1;
	
	for(int i=5;i<=10;i++)
	{
		for(int j=1;j<=10;j++)
		{
			cout<<i<<"*"<<j<<"="<<i*j<<endl;
		}
	}


	return 0;
}

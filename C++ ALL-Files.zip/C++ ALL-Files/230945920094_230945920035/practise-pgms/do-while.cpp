#include<iostream>
#include<Math.h>
using namespace std;

int main()
{
	int i,sum=0;
do{
	cin>>i;
	sum=sum+i;
}while(i!=0);
cout<<"sum is : "<<sum;
	return 0;
}

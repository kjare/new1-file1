#include<iostream>
#include<Math.h>
using namespace std;

int main()
{
	
	int a,b,ans=1;
	cout<<"Enter the base value";
	cin>>a;
	cout<<"Enter the exponent value";
	cin>>b;
ans=pow(a,b);

	cout<<ans;
	return 0;
}

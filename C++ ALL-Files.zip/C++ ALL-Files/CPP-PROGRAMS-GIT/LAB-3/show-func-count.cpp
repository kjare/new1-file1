#include<iostream>
using namespace std;
int cnt=0;

void show()
{
	cnt++;
		cout<<cnt;

}
int main()
{
	show();
	//cout<<cnt;
	return 0;
}

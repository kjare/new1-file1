#include<iostream>
using namespace std;

int main()
{
	int ans=0,t=1;
	while(t<=20)
	{
		ans=ans+t;
		t++;
	}
	cout<<ans;
	return 0;
}

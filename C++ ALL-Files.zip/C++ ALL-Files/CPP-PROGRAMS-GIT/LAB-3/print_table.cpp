#include<iostream>
using namespace std;

int main()
{
	int n=5,ans=1,t=1;
	while(t<=10)
	{
		cout<<n<<"*"<<t<<"="<<n*t<<endl;
		t++;
	}
	return 0;
}

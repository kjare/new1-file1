#include<iostream>
using namespace std;

int main()
{
	int sum_e=0,sum_o=0,n=20;
	
	for(int i=0;i<=20;i++)
	{
		if(i%2==0)
		{
			sum_e=sum_e+i;
		}
		else
		{
			sum_o=sum_o+i;
		}
	}
	
	cout<<"Sum of odd nos from 1-20 : "<<sum_o<<endl;
	cout<<"Sum of even nos from 1-20 : "<<sum_e<<endl;
	return 0;
}

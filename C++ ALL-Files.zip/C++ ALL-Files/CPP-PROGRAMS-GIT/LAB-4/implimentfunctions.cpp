#include <iostream>
using namespace std;

void sum(int a,int b)
{
    cout<<"Sum of a and b : "<<a+b<<endl;
}

void sub(int a,int b)
{
    cout<<"Subtraction of a and b : "<<a-b<<endl;
}
int main()
{
sum(564,390); 
sub(500,400);
}

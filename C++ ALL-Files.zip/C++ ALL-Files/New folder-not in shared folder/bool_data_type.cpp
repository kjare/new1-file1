#include<iostream>
using namespace std;
int main()
{
	bool flag = true;
	if(flag ==1)
	cout <<true;
}

#include <iostream>
#include "Shape.h"
#include "Point.h"
#include "Line.h"
#include "Square.h"
#include "Rectangle.h"
#include "Circle.h"
#include "Ellipse.h"
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()
{
	int n;
/*	Shape s;
	s.getThickness();
	s.display();
	
	Point p;
	p.getPointCo_ordinates();
	p.displayPointCo_ordinates();
	
	Line l1;
	l1.getLineCo_ordinates();
	l1.displayLineCo_ordinates();
	
	Square sq;
	sq.getSide();
	sq.calculateArea();
	sq.displayArea();     
	
	Rectangle r;
	r.getValues();
	r.calculateArea();
	r.displayArea();
	
	Circle c;
	c.getRadius();
	c.calculateArea();
	c.displayArea();
	c.getCenterCo_ordinates();
	c.displayCenterCo_ordinates();
	//Point::displayPointCo_ordinates();	//getting center points co-ordinates from Point class
	 
	Ellipse e;
	e.getValues();
	e.calculateArea();
	e.displayArea();
	e.getPointCo_ordinates();
	e.displayPointCo_ordinates();*/
	
	cout<<"\n1.Shape\n2.Line\n3.Square\n4.Rectangle\n5.Ellipse\nEnter your choice\nEnter otherwise to exit";
	cin>>n;
	switch(n)
	{
		case 1:
			Shape s;
			s.getThickness();
			s.display();
			break;
		case 2:
			Line l1;
			l1.getLineCo_ordinates();
			l1.displayLineCo_ordinates();
			break;
		case 3:
			Square sq;
			sq.getSide();
			sq.calculateArea();
			sq.displayArea();  
			break;
		case 4:
			Rectangle r;
			r.getValues();
			r.calculateArea();
			r.displayArea();
			break;
		case 5:
			Circle c;
			c.getRadius();
			c.calculateArea();
			c.displayArea();
			c.getCenterCo_ordinates();
			c.displayCenterCo_ordinates();
			break;
		case 6:	
			Ellipse e;
			e.getValues();
			e.calculateArea();
			e.displayArea();
			e.getPointCo_ordinates();
			e.displayPointCo_ordinates();
			break;
		default:
			break;
			
	}

	return 0;
}

#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "Shape.h"

class Rectangle : public Shape
{
	public:
		int length,breadth,area;
		
		void getValues();
		void calculateArea();
		void displayArea();
};

#endif

#ifndef LINE_H
#define LINE_H

#include "Point.h"
#include "Shape.h"
class Line : public Point, Shape
{
	public:
		int x1,y1,x2,y2;
		void getLineCo_ordinates();
		void displayLineCo_ordinates();

};

#endif

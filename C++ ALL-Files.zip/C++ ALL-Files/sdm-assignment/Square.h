#ifndef SQUARE_H
#define SQUARE_H

#include "Shape.h"

class Square : public Shape
{
	public:
		int side,area;
		void getSide();
		void calculateArea();
		void displayArea();
};

#endif

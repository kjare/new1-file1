#include "Line.h"
#include <iostream>
using namespace std;
void Line::getLineCo_ordinates()
{
	cout<<" LINE : "<<endl;
	cout<<"enter 'starting point's x and y co-ordinates : ";
	cin>>x1>>y1;
	cout<<"enter ending point's x and y co-ordinates : ";
	cin>>x2>>y2;
	
}

void Line::displayLineCo_ordinates()
{
	cout<<" LINE : "<<endl;
	cout<<" Starting point's  co-ordinates : "<<"("<<x1<<","<<y1<<")";
	cout<<" Ending point's  co-ordinates : "<<"("<<x2<<","<<y2<<")";
}

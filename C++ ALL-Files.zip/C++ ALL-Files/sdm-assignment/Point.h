#ifndef POINT_H
#define POINT_H

class Point
{
	public:
		int x,y;
		//Point();
		void getPointCo_ordinates();
		void displayPointCo_ordinates();
	
};

#endif

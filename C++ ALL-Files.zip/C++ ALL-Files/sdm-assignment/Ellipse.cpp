#include "Ellipse.h"
#include "Shape.h"
#include <iostream>
using namespace std;

const float pi = 3.142f;

void Ellipse::getValues()
{
	cout<<" ELLIPSE : "<<endl;
	cout<<"Enter length & height of a rectangle: ";
	cin>>length>>height;
}


void Ellipse::calculateArea()
{
	area=pi*length*height;
}
void Ellipse::displayArea()
{
	cout<<"Area of Ellipse : "<<area<<endl;
}

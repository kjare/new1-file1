#include "Circle.h"
#include "Point.h"
#include <iostream>
using namespace std;

void Circle::getCenterCo_ordinates()
{
	cout<<" For CENTER : ";
	Point::getPointCo_ordinates();
}

void Circle::displayCenterCo_ordinates()
{
	cout<<" For CENTER : ";
	Point::displayPointCo_ordinates();
}
void Circle::getRadius()
{
	cout<<" CIRCLE : "<<endl;
	cout<<"Enter radius of circle: ";
	cin>>radius;
}

void Circle::calculateArea()
{
	area=pi*radius*radius;
}
void Circle::displayArea()
{
	cout<<"Area of circle : "<<area<<endl;
}

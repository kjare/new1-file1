#ifndef ELLIPSE_H
#define ELLIPSE_H

#include "Shape.h"
#include "Point.h"


class Ellipse : public Shape,public Point
{
	public:
		int length,height,area;
		void getValues();
		void calculateArea();
		void displayArea();
};

#endif

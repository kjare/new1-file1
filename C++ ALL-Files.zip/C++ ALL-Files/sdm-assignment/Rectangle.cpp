#include "Rectangle.h"
#include <iostream>
using namespace std;

void Rectangle::getValues()
{
	cout<<" RECTANGLE : "<<endl;
	cout<<"Enter length & breadth of a rectangle: ";
	cin>>length>>breadth;
}


void Rectangle::calculateArea()
{
	area=length*breadth;
}
void Rectangle::displayArea()
{
	cout<<"Area of Rectangle : "<<area<<endl;
}

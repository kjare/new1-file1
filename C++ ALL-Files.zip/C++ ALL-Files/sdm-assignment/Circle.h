#ifndef CIRCLE_H
#define CIRCLE_H

#include "Shape.h"
#include "Point.h"
const float pi = 3.142f;
class Circle : public Point,public Shape
{
	public:
		float radius,area;
		
		void getRadius();
		void calculateArea();
		void displayArea();
		void displayCenterCo_ordinates();
		void getCenterCo_ordinates();
};

#endif

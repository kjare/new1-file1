#include "Shape.h"
#include <iostream>
using namespace std;
//Shape::Shape()
//{	
//}

void Shape::getThickness()
{	
	cout<<"Enter thickness";
	cin>>thickness;
}
void Shape::display()
{
	cout<<"Thickness is : "<<thickness<<endl;
}


#include "Point.h"
#include <iostream>
using namespace std;
//Point::Point()
//{
//	
//}

void Point::getPointCo_ordinates()
{
	//cout<<" POINT : "<<endl;
	cout<<"Enter x and y co-ordinates : ";
	cin>>this->x>>this->y;

}

void Point::displayPointCo_ordinates()
{
	//cout<<" POINT : "<<endl;
	cout<<" Point's  co-ordinates : "<<"("<<this->x<<","<<this->y<<")"<<endl;
	
}

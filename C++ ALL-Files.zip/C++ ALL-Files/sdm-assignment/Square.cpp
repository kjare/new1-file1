#include "Square.h"
#include <iostream>
using namespace std;
void Square::getSide()
{
	cout<<" SQUARE : "<<endl;
	cout<<"Enter side's length : ";
	cin>>side;
}

void Square::calculateArea()
{
	area=side*side;
}

void Square::displayArea()
{
	cout<<"Area of Square : "<<area<<endl;
}

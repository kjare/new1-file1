#ifndef SHAPE_H
#define SHAPE_H

class Shape
{
	public:
		float thickness;
	//	Shape();
		void getThickness();
		void display();
};

#endif

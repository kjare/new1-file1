#include<iostream>
using namespace std;
int main()
{
	int r;
	const float pi=3.142f;
	cout<<"enter radius"<<endl;
	cin>>r;
	float circum=2*pi*r;
	cout<<"circumference is"<<circum;
	return 0;
	
}

